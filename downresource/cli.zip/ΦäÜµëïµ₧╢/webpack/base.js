const VueLoaderPlugin = require('vue-loader/lib/plugin')
const webpack = require('webpack')
const path = require('path')
const inProductionMode = process.env.NODE_ENV === 'production'
const CleanWebpackPlugin = require('clean-webpack-plugin')
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin
const MomentLocalesPlugin = require('moment-locales-webpack-plugin')

const base = {
  resolve: {
    extensions: ['.js', '.vue', '.json'],
    alias: {
      '@': path.resolve(__dirname, '../src'),
      'vue$': `vue/dist/vue.runtime.${inProductionMode ? 'min' : 'esm'}.js`
    }
  },
  module: {
    noParse: /^(vue|vue-router|vuex)$/,
    rules: [
      {
        test: /\.vue$/,
        use: [
          {
            loader: 'cache-loader',
            options: {
              cacheDirectory: path.resolve(__dirname, '../build-cache/vue')
            }
          },
          {
            loader: 'vue-loader',
            options: {
              cacheDirectory: path.resolve(__dirname, '../build-cache/vue') 
            }
          },
          {
            loader: 'eslint-loader',
            options: {
              cache: true
            }
          }
        ]
      },
      {
        test: /\.jsx?$/,
        use: [
          {
            loader: 'cache-loader',
            options: {
              cacheDirectory: path.resolve(__dirname, '../build-cache/js')
            }
          }, 
          'babel-loader',
          {
            loader: 'eslint-loader',
            options: {
              cache: true,
              cacheDirectory: true
            }
          },
        ],
        exclude: [
          path.resolve(__dirname, '../src/common/html2canvas')
        ],
        include: [
          path.resolve(__dirname, '../src'),
          path.resolve(__dirname, '../node_modules/vue-ueditor-wrap')
        ]
      },
    {
      test: /\.(scss|css)$/,
      use: [
        'style-loader',
        'css-loader',
        'sass-loader',
        {
          loader: 'sass-resources-loader',
          options: {
            resources: path.resolve(__dirname, '../src/assets/css/base_var.scss')
          }
        }
      ]
    },
    {
      test: /\.(png|jpg|gif|svg|eot|woff|woff2|ttf)$/,
      use: {
        loader: 'url-loader',
        options: {
          limit: 20480
        }
      }
    }]
  },
  plugins: [
    // new BundleAnalyzerPlugin(),
    new MomentLocalesPlugin(),
    new VueLoaderPlugin(),
    new webpack.DefinePlugin({
      'STATIC_DIR': inProductionMode ? '"/iform_web/static/static/"' : '/static/'
    })
  ]
}
module.exports = base