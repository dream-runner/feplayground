module.exports = {
  presets: [
    ['@vue/app', {
      polyfills: [
        'es7.promise.finally'
      ]
    }]
  ],
  "plugins": [
    [
      "component",
      {
        "libraryName": "element-ui",
        "styleLibraryName": "~src/assets/css/theme"
      }
    ]
  ]
}
