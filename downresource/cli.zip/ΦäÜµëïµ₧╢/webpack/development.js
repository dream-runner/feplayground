const HtmlWebpackPlugin = require('html-webpack-plugin')
const modules = require('../src/modules')
const merge = require('webpack-merge')
const base = require('./base')
const webpack = require('webpack')
const path = require('path')
const CopyWebpackPlugin = require('copy-webpack-plugin')

module.exports = merge(base, {
  mode: 'development',
  optimization: {
    removeAvailableModules: false,
    removeEmptyChunks: false,
    splitChunks: false
  },
  devServer: {
    hot: true,
    disableHostCheck: true,
    stats: {
      all: false,
      warnings: true,
      timings: true,
      errors: true,
      assets: false
    },
    inline: true,
    port: 8081,
    // port: 9999,
    proxy: {
      '/': {
        // target: 'https://yb-u8c-daily.yyuap.com/',
        // target: 'http://127.0.0.1:8080/',
        // target: 'http://123.103.9.201:10210/',
        // target: 'http://10.11.66.49:8080',
        target: 'http://yb.chaoke.com:91',
        // target: 'http://yb.fjqfoa.com:81',
        // target: 'http://yb91.yyuap.com:91',
        // target: 'https://yb.esn.ren',
        // target: 'https://yb.yonyoucloud.com',
        // target: 'https://yb.diwork.com',
        // target: 'https://yb-daily.yyuap.com/',
        secure: false,
        changeOrigin: true
      }
    },
  },
  devtool: 'eval-source-map',
  entry: (() => {
    const entries = {}
    modules.forEach(m => {
      entries[m] = path.resolve(__dirname, `../src/${m}/main.js`)
    })
    entries['flow-comp'] = path.resolve(__dirname, '../src/common/flow-comp/index.js')
    return entries
  })(),
  output: {
    pathinfo: false,
    filename: '[name].js',
    path: __dirname + '/dist'
  },
  plugins: [
    ...modules.map(module => {
      return new HtmlWebpackPlugin({
        chunks: [module],
        filename: `${module}.html`,
        template: `./src/${module}/index.html`
      })
    }).concat([
      new HtmlWebpackPlugin({
        chunks: ['flow-comp'],
        filename: `flow-comp.html`,
        template: `./src/common/flow-comp/dev.html`
      })
    ]),
    new webpack.HotModuleReplacementPlugin(),
    new CopyWebpackPlugin(
      [{
        from: path.resolve(__dirname, '../static'),
        to: 'static',
        ignore: ['.*']
      }]
    )
  ],
})